package com.bawei.zhaochenyu1709a;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.graphics.Canvas;
import android.os.Bundle;
import android.widget.EditText;

import com.bawei.zhaochenyu1709a.base.BaseActivity;
import com.bawei.zhaochenyu1709a.base.mvp.BasePresenter;
import com.bawei.zhaochenyu1709a.bean.ShowBean;
import com.bawei.zhaochenyu1709a.contract.IshowContract;
import com.bawei.zhaochenyu1709a.presenter.IshowPresenter;
import com.bawei.zhaochenyu1709a.view.ShowAdapter;
import com.bumptech.glide.load.Encoder;
import com.google.gson.Gson;

import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends BaseActivity<IshowPresenter> implements IshowContract.Iview {


    private RecyclerView mRc;
    private EditText mEt;


    @Override
    protected void initData() {
//        String str = mEt.getText().toString();
//        String decode = URLDecoder.decode(str);
        present.getshow("http://blog.zhaoliang5156.cn/baweiapi/searchmusic?kword=%E6%AC%A7%E7%BE%8E%E9%87%91%E6%9B%B2%E6%A6%9C");
    }

    @Override
    protected void initView() {
        mRc = findViewById(R.id.rc);
        mRc.setLayoutManager(new LinearLayoutManager(this,RecyclerView.VERTICAL,false));
        mEt = findViewById(R.id.et);
    }

    @Override
    protected IshowPresenter InitPresent() {
        return new IshowPresenter(this);
    }

    @Override
    protected int Layoutid() {
        return R.layout.activity_main;

    }

    @Override
    public void success(String url) {
        Gson gson=new Gson();
        ShowBean showBean = gson.fromJson(url, ShowBean.class);
        List<ShowBean.ContentBean> content = showBean.getContent();
        ShowAdapter showAdapter=new ShowAdapter(this,content);
        mRc.setAdapter(showAdapter);
    }

    @Override
    public void error(String url) {

    }
}
