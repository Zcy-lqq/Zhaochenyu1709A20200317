package com.bawei.zhaochenyu1709a.view;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bawei.zhaochenyu1709a.R;
import com.bawei.zhaochenyu1709a.bean.ShowBean;
import com.bumptech.glide.Glide;


import java.util.List;

public class ShowAdapter extends RecyclerView.Adapter<ShowAdapter.ViewHodel> {

    Context mContext;
    List<ShowBean.ContentBean> mContentBeanList;

    public ShowAdapter(Context context, List<ShowBean.ContentBean> contentBeanList) {
        mContext = context;
        mContentBeanList = contentBeanList;
    }

    @NonNull
    @Override
    public ViewHodel onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHodel(View.inflate(mContext, R.layout.show_adapter,null));

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHodel holder, int position) {
        Glide.with(mContext).load(mContentBeanList.get(position).getPic_big()).into(holder.mImage);
        holder.mText.setText(mContentBeanList.get(position).getTitle());
    }

    @Override
    public int getItemCount() {
        return mContentBeanList.size();
    }

    class ViewHodel extends RecyclerView.ViewHolder{

        private final ImageView mImage;
        private final TextView mText;

        public ViewHodel(@NonNull View itemView) {
            super(itemView);
            mImage = itemView.findViewById(R.id.image);
            mText = itemView.findViewById(R.id.text);
        }
    }
}
