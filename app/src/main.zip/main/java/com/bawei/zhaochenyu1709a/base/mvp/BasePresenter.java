package com.bawei.zhaochenyu1709a.base.mvp;

import java.lang.ref.WeakReference;

public abstract class BasePresenter<M extends BaseModle,V extends BaseView> {
    public M model;
    public WeakReference<V> mVWeakReference;

    public BasePresenter(BaseView baseView) {
        model=InitModle();
    }

    protected abstract M InitModle();


    public void attach(V v){
        mVWeakReference=new WeakReference<>(v);
    }

    public void deatch(){
        mVWeakReference.clear();
        mVWeakReference=null;
    }

    public V getview(){
        return  mVWeakReference.get();
    }

}
