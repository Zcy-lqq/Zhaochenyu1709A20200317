package com.bawei.zhaochenyu1709a.base.mvp;

public interface BaseModle {
}
