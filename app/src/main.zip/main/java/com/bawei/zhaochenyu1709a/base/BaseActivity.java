package com.bawei.zhaochenyu1709a.base;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.bawei.zhaochenyu1709a.base.mvp.BasePresenter;
import com.bawei.zhaochenyu1709a.contract.IshowContract;

public abstract class BaseActivity<P extends BasePresenter> extends AppCompatActivity implements IshowContract.Iview {

    public P present;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(Layoutid());
        present=InitPresent();
        if (present != null) {
            present.attach(this);
        }
        initView();
        initData();
    }

    protected abstract void initData();

    protected abstract void initView();

    protected abstract P InitPresent();

    protected abstract int Layoutid();
}
